import re
from typing import Tuple, Optional

class FareRuleMatcher:
    def __init__(self):
        self.rules = [
            {
                'name': 'Refund Policy',
                'pattern': r'\b(non[-\s]?refundable|no\srefund|non[-\s]?refundable\sfares?)\b',
            },
            {
                'name': 'Change Policy', 
                'pattern': r'\b(change(s)?\sallowed|reissue(s)?\sallowed|modifications?\sallowed|change(s)?\snot\sallowed|no\schanges)\b',
            },
            {
                'name': 'Penalty Policy',
                'pattern': r'\b(penalt(y|ies)|charges?|fees?)\b',
            },
            {
                'name': 'Stopover Policy',
                'pattern': r'\b(stopover(s)?|transit(s)?)\b',
            },
            {
                'name': 'Validity Policy',
                'pattern': r'\b(valid(ity)?|expir(y|ation|es)?)\b',
            },
            {
                'name': 'Ticket Policy',
                'pattern': r'\b(coupon(s)?|ticket(s)?)\b',
            },
            {
                'name': 'Discount Policy',
                'pattern': r'\b(discount(s)?|child(ren)?|infant(s)?)\b',
            },
            {
                'name': 'Flight Policy',
                'pattern': r'\b(flight(s)?|departure(s)?|arrival(s)?)\b',
            },
        ]

    def match_rule(self, text: str) -> Tuple[Optional[str], Optional[str]]:
        """Match text against known fare rule patterns"""
        if not text:
            return None, None
            
        text_lower = text.lower()
        for rule in self.rules:
            if re.search(rule['pattern'], text_lower, flags=re.IGNORECASE):
                return rule['name'], text
        return None, None

    def generate_flexible_pattern(self, phrase: str) -> Optional[str]:
        """Generate a comprehensive flexible regex pattern from a phrase"""
        if not phrase:
            return None
        
        try:
            # Convert to uppercase for consistency
            phrase = phrase.upper()
            
            # Enhanced pattern generation with comprehensive coverage
            pattern = self._create_safe_pattern(phrase)
            
            return pattern
        except Exception as e:
            print(f"Error in generate_flexible_pattern: {e}")
            # Fallback to simple escape
            return re.escape(phrase)
    
    def _create_safe_pattern(self, phrase: str) -> str:
        """Create pattern using safe string operations"""
        
        # Use the same simplified approach as phrase_to_regex
        from phrase_to_regex import create_simple_pattern
        
        try:
            return create_simple_pattern(phrase)
        except Exception:
            # Fallback to simple escape if anything fails
            return f'(?i)^\\s*{re.escape(phrase)}\\s*$'
    
    def _process_single_word(self, word: str) -> str:
        """Process a single word safely"""
        word_upper = word.upper()
        word_clean = re.sub(r'[^\w]', '', word_upper)  # Remove punctuation for matching
        
        # Check for specific patterns
        if self._is_currency_code(word_clean):
            return '[A-Z]{3}'
        elif self._is_number(word):
            return r'\d+(?:[,\.]\d+)*'
        elif self._is_currency_symbol(word):
            return r'[\$₹€£¥₩¢]\d+(?:[,\.]\d+)*'
        elif self._is_flight_code(word_upper):
            return r'[A-Z]{1,3}\d{1,5}[A-Z]?'
        elif self._is_date(word):
            return r'\d{1,2}[\-\/\.]\d{1,2}[\-\/\.]\d{2,4}'
        elif self._is_month(word_upper):
            return f'(?:{word_upper})'
        elif self._is_plural_word(word_clean):
            base_word = word_clean.rstrip('S') if word_clean.endswith('S') else word_clean
            return f'(?:{base_word}|{base_word}S)'
        else:
            # Regular word - escape special characters
            return re.escape(word)
    
    def _is_currency_code(self, word: str) -> bool:
        """Check if word is a 3-letter currency code"""
        return len(word) == 3 and word.isalpha()
    
    def _is_number(self, word: str) -> bool:
        """Check if word is a number"""
        return bool(re.match(r'^\d+(?:[,\.]\d+)*(?:[,\.]\d{1,2})?$', word))
    
    def _is_currency_symbol(self, word: str) -> bool:
        """Check if word starts with currency symbol"""
        return bool(re.match(r'^[\$₹€£¥₩¢]\d+', word))
    
    def _is_flight_code(self, word: str) -> bool:
        """Check if word is a flight code"""
        return bool(re.match(r'^[A-Z]{1,3}\d{1,5}[A-Z]?$', word))
    
    def _is_date(self, word: str) -> bool:
        """Check if word is a date"""
        return bool(re.match(r'^\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4}$', word))
    
    def _is_month(self, word: str) -> bool:
        """Check if word is a month abbreviation"""
        months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 
                 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
        return word in months
    
    def _is_plural_word(self, word: str) -> bool:
        """Check if word is a common aviation term that can be plural"""
        plural_words = ['TICKET', 'YEAR', 'MONTH', 'DAY', 'PENALTY', 'FEE', 
                       'CHARGE', 'PASSENGER', 'REFUND', 'CHANGE', 'CHILD', 
                       'INFANT', 'STOP', 'STOPOVER', 'COUPON', 'FARE', 
                       'COMPONENT', 'COUNTRY', 'FLIGHT']
        
        # Check if word itself is in the list or if base word (without S) is in the list
        return word in plural_words or (word.endswith('S') and word[:-1] in plural_words)