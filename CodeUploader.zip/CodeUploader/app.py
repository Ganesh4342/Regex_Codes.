import streamlit as st
import re
import pandas as pd
import tempfile
import os
from regex_generator import RegexGenerator

# Configure page
st.set_page_config(
    page_title="Regex Pattern Generator",
    page_icon="🔍",
    layout="wide"
)

# Initialize session state
if 'generated_patterns' not in st.session_state:
    st.session_state.generated_patterns = []

def main():
    """Main application function"""
    st.title("🔍 Regex Pattern Generator")
    st.markdown("Generate and test regular expression patterns from phrases with advanced airline fare rule support")
    
    # Create tabs for different functionalities
    tab1, tab2, tab3, tab4 = st.tabs(["Manual Input", "Excel Processing", "Pattern Testing", "Additional Tools"])
    
    with tab1:
        manual_input_interface()
    
    with tab2:
        excel_upload_interface()
    
    with tab3:
        pattern_testing_section()
    
    with tab4:
        additional_tools_section()

def manual_input_interface():
    """Interface for manual phrase input"""
    # Create two columns for layout
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.header("Pattern Generation")
        
        # Input for phrases
        phrases_input = st.text_area(
            "Enter phrases (one per line):",
            height=150,
            placeholder="Enter your phrases here...\nExample:\nhello@example.com\ntest@domain.org\n+1-555-123-4567"
        )
        
        # Pattern type selection
        pattern_type = st.selectbox(
            "Pattern Type:",
            ["Auto-detect", "Email", "Phone Number", "URL", "Date", "IP Address", "Advanced Airline", "Custom"]
        )
        
        # Generation options
        st.subheader("Options")
        case_sensitive = st.checkbox("Case Sensitive", value=False)
        match_whole_word = st.checkbox("Match Whole Words", value=False)
        
        # Generate button
        if st.button("Generate Regex Pattern", type="primary", key="manual_generate"):
            if phrases_input.strip():
                phrases = [p.strip() for p in phrases_input.split('\n') if p.strip()]
                generator = RegexGenerator()
                
                try:
                    # Generate regex patterns
                    patterns = generator.generate_patterns(
                        phrases, 
                        pattern_type, 
                        case_sensitive, 
                        match_whole_word
                    )
                    
                    st.session_state.generated_patterns = patterns
                    st.success(f"Generated {len(patterns)} pattern(s)!")
                    
                except Exception as e:
                    st.error(f"Error generating patterns: {str(e)}")
                    st.error(f"Debug info: Please check your input phrases for special characters")
            else:
                st.warning("Please enter some phrases to generate patterns.")
    
    with col2:
        display_generated_patterns()

def excel_upload_interface():
    """Interface for Excel file upload and processing"""
    st.header("Excel File Processing")
    
    # File upload
    uploaded_file = st.file_uploader(
        "Upload your Excel file",
        type=['xlsx', 'xls'],
        help="Upload an Excel file with phrases in the first column"
    )
    
    if uploaded_file is not None:
        if st.button("Process Uploaded File", type="primary"):
            try:
                # Save uploaded file temporarily
                with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp_file:
                    tmp_file.write(uploaded_file.getvalue())
                    tmp_file_path = tmp_file.name
                
                generator = RegexGenerator()
                df = generator.process_excel_file(tmp_file_path)
                
                st.session_state['processed_df'] = df
                st.session_state['temp_file_path'] = tmp_file_path
                st.success(f"Processed {len(df)} rows from the uploaded file!")
                
            except Exception as e:
                st.error(f"Error processing uploaded file: {str(e)}")
                
                # Provide more specific error guidance
                error_msg = str(e).lower()
                if "length" in error_msg and "match" in error_msg:
                    st.error("📋 **Data Issue**: The Excel file has inconsistent row counts. This can happen when:")
                    st.write("• Some rows are completely empty")
                    st.write("• The file has merged cells") 
                    st.write("• There are hidden rows or formatting issues")
                    st.write("**Solution**: Try saving your Excel file as a new .xlsx file with only the data you need.")
                elif "empty" in error_msg:
                    st.error("📋 **Empty File**: The uploaded Excel file appears to be empty or has no data.")
                else:
                    st.error("📋 **General Guidance**: Please ensure your Excel file:")
                    st.write("• Has phrases in the first column")
                    st.write("• Is saved as .xlsx or .xls format")
                    st.write("• Contains actual text data (not just headers)")
                    st.write("• Has no merged cells or complex formatting")
    
    # Display processed data and combination feature
    if 'processed_df' in st.session_state:
        df = st.session_state['processed_df']
        
        st.subheader("Processing Results")
        
        # Display summary statistics
        col_stats1, col_stats2, col_stats3 = st.columns(3)
        with col_stats1:
            st.metric("Total Phrases", len(df))
        with col_stats2:
            pattern_types = df['Pattern_Type'].value_counts()
            st.metric("Pattern Types", len(pattern_types))
        with col_stats3:
            avg_confidence = df['Confidence'].mean()
            st.metric("Avg Confidence", f"{avg_confidence:.1%}")
        
        # Pattern Combination Section
        st.subheader("🔗 Pattern Combination")
        st.markdown("Combine all valid patterns into a single comprehensive regex")
        
        col_combine1, col_combine2 = st.columns([2, 1])
        
        with col_combine1:
            # Show combination preview
            valid_pattern_count = len(df[(df['Pattern_Type'] != 'Error') & 
                                       (df['Pattern_Type'] != 'Empty') & 
                                       (df['Generated_Regex'].notna()) & 
                                       (df['Generated_Regex'] != '')])
            
            st.info(f"📊 Found {valid_pattern_count} valid patterns ready for combination")
            
            if valid_pattern_count > 0:
                # Show pattern type distribution for combination
                valid_df = df[(df['Pattern_Type'] != 'Error') & 
                            (df['Pattern_Type'] != 'Empty') & 
                            (df['Generated_Regex'].notna()) & 
                            (df['Generated_Regex'] != '')]
                
                type_dist = valid_df['Pattern_Type'].value_counts()
                st.write("**Pattern Types to be Combined:**")
                for pattern_type, count in type_dist.items():
                    st.write(f"• {pattern_type}: {count} patterns")
        
        with col_combine2:
            # Combine patterns button
            if st.button("🔗 Combine All Patterns", type="primary", key="combine_patterns"):
                if valid_pattern_count > 0:
                    progress_bar = st.progress(0)
                    status_text = st.empty()
                    
                    try:
                        status_text.text("Starting pattern combination...")
                        progress_bar.progress(10)
                        
                        generator = RegexGenerator()
                        
                        status_text.text("Processing patterns...")
                        progress_bar.progress(50)
                        
                        combination_result = generator.combine_regex_patterns(df)
                        progress_bar.progress(90)
                        
                        if combination_result['success']:
                            st.session_state['combination_result'] = combination_result
                            progress_bar.progress(100)
                            status_text.text("✅ Combination completed!")
                            st.success(f"✅ {combination_result['message']}")
                            
                            # Browser compatibility notice
                            st.info("💡 Tip: If the page appears frozen after processing, try refreshing your browser or switching to Chrome/Firefox for better performance.")
                        else:
                            status_text.text("❌ Combination failed")
                            st.error(f"❌ {combination_result['message']}")
                            
                        # Clear progress indicators after delay
                        import time
                        time.sleep(0.5)  # Reduced delay
                        progress_bar.empty()
                        status_text.empty()
                        
                    except Exception as e:
                        progress_bar.empty()
                        status_text.empty()
                        st.error(f"❌ Error during combination: {str(e)}")
                        st.info("💡 Try refreshing the page if it appears frozen.")
                else:
                    st.warning("No valid patterns found to combine")
        
        # Display combined pattern if available
        if 'combination_result' in st.session_state:
            result = st.session_state['combination_result']
            
            if result['success']:
                st.subheader("🎯 Combined Regex Pattern")
                
                # Display the combined pattern
                combined_pattern = result['combined_pattern']
                st.code(combined_pattern, language='regex')
                
                # Copy button for combined pattern
                if st.button("📋 Copy Combined Pattern", key="copy_combined"):
                    st.success("Pattern copied! You can now use this in regex101.com or other tools.")
                    st.code(combined_pattern, language='regex')
                
                # Pattern statistics
                col_stats_combined1, col_stats_combined2 = st.columns(2)
                with col_stats_combined1:
                    st.metric("Patterns Combined", result['pattern_count'])
                with col_stats_combined2:
                    pattern_length = len(combined_pattern)
                    st.metric("Pattern Length", f"{pattern_length} chars")
                
                # Save to Excel button
                if st.button("💾 Add Combined Pattern to Excel", key="save_combined"):
                    if 'temp_file_path' in st.session_state:
                        temp_file_path = st.session_state['temp_file_path']
                        generator = RegexGenerator()
                        
                        try:
                            # First save the processed data to the temp file
                            df.to_excel(temp_file_path, index=False)
                            
                            # Then use the direct method that adds CombinedRegex sheet
                            combined_pattern = generator.process_and_combine_regex(
                                temp_file_path, 
                                sheet=0, 
                                regex_col='Generated_Regex'
                            )
                            
                            st.success("✅ Combined regex added to 'CombinedRegex' sheet in the original file!")
                            
                            # Create download button for the updated file
                            try:
                                with open(temp_file_path, "rb") as file:
                                    # Create output filename for download
                                    output_filename = "Enhanced_Regex_Patterns_with_CombinedRegex.xlsx"
                                    st.download_button(
                                        label="📥 Download Excel File with Combined Regex",
                                        data=file.read(),
                                        file_name=output_filename,
                                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                        key="download_combined"
                                    )
                            except Exception as e:
                                st.error(f"Error creating download: {str(e)}")
                        except Exception as e:
                            st.error(f"❌ Error adding combined pattern: {str(e)}")
                    else:
                        st.error("Original file path not found. Please re-upload the file.")
                
                # Show pattern breakdown in expandable section
                with st.expander("📊 Pattern Breakdown Details", expanded=False):
                    if not result['breakdown_df'].empty:
                        st.dataframe(result['breakdown_df'], use_container_width=True)
                    
                    if not result['summary_df'].empty:
                        st.subheader("Summary Information")
                        st.dataframe(result['summary_df'], use_container_width=True)
        
        # Display sample results (existing functionality)
        st.subheader("Sample Enhanced Patterns")
        
        # Determine which regex column to use
        regex_col = 'Generated_Regex' if 'Generated_Regex' in df.columns else 'Updated_Regex'
        
        # Show first 10 results
        display_cols = [df.columns[0], regex_col, 'Pattern_Type', 'Confidence'] 
        sample_df = df.head(10)[display_cols].copy()
        
        # Truncate long text for better display
        for col in [df.columns[0], regex_col]:
            if col in sample_df.columns:
                sample_df[col] = sample_df[col].astype(str).str[:80] + "..."
        
        st.dataframe(sample_df, use_container_width=True)
        
        # Download button for processed file (existing functionality)
        if st.button("📥 Download Enhanced Excel File", key="download_original"):
            try:
                output_filename = "Enhanced_Regex_Patterns.xlsx"
                df.to_excel(output_filename, index=False)
                
                with open(output_filename, "rb") as file:
                    st.download_button(
                        label="Download Excel file",
                        data=file.read(),
                        file_name=output_filename,
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )
            except Exception as e:
                st.error(f"Error creating download file: {str(e)}")
        
        # Display pattern type distribution (existing functionality)
        if len(df) > 0:
            st.subheader("Pattern Type Distribution")
            pattern_counts = df['Pattern_Type'].value_counts()
            st.bar_chart(pattern_counts)

def display_generated_patterns():
    """Display generated patterns in a consistent format"""
    st.header("Generated Patterns")
    
    if st.session_state.generated_patterns:
        for i, pattern_info in enumerate(st.session_state.generated_patterns):
            with st.expander(f"Pattern {i+1}: {pattern_info['type']}", expanded=True):
                # Display the regex pattern
                st.code(pattern_info['pattern'], language='regex')
                
                # Copy button
                if st.button(f"📋 Copy Pattern {i+1}", key=f"copy_{i}"):
                    st.write("Pattern copied to clipboard!")
                    st.code(pattern_info['pattern'], language='regex')
                
                # Pattern explanation
                if pattern_info.get('explanation'):
                    st.write("**Explanation:**")
                    st.write(pattern_info['explanation'])
                
                # Confidence score and validity
                col_conf, col_valid = st.columns(2)
                with col_conf:
                    if pattern_info.get('confidence'):
                        st.metric("Confidence", f"{pattern_info['confidence']:.1%}")
                with col_valid:
                    if pattern_info.get('valid') is not None:
                        status = "✅ Valid" if pattern_info['valid'] else "❌ Invalid"
                        st.write(f"**Status:** {status}")
                        if not pattern_info['valid'] and pattern_info.get('validation_message'):
                            st.error(f"Error: {pattern_info['validation_message']}")
    else:
        st.info("No patterns generated yet. Enter some phrases and click 'Generate Regex Pattern'.")

def pattern_testing_section():
    """Pattern testing interface"""
    st.header("🧪 Pattern Testing")
    
    # Test combined pattern if available
    if 'combination_result' in st.session_state and st.session_state['combination_result']['success']:
        st.subheader("Test Combined Pattern")
        combined_pattern = st.session_state['combination_result']['combined_pattern']
        
        test_combined_text = st.text_area(
            "Test combined pattern against text:",
            height=100,
            placeholder="Enter text to test the combined regex pattern...",
            key="test_combined"
        )
        
        if test_combined_text.strip():
            try:
                regex = re.compile(combined_pattern)
                matches = list(regex.finditer(test_combined_text))
                
                col_combined1, col_combined2 = st.columns([1, 1])
                
                with col_combined1:
                    st.metric("Combined Pattern Matches", len(matches))
                    if matches:
                        st.success("✅ Combined pattern matches found!")
                        for i, match in enumerate(matches):
                            st.write(f"Match {i+1}: `{match.group()}` (pos {match.start()}-{match.end()})")
                    else:
                        st.warning("❌ No matches found with combined pattern")
                
                with col_combined2:
                    if matches:
                        highlighted_text = test_combined_text
                        for match in reversed(matches):  # Reverse to maintain positions
                            start, end = match.span()
                            highlighted_text = (
                                highlighted_text[:start] + 
                                f"**[{match.group()}]**" + 
                                highlighted_text[end:]
                            )
                        st.markdown("**Highlighted Text:**")
                        st.markdown(highlighted_text)
                        
            except re.error as e:
                st.error(f"Combined pattern error: {str(e)}")
        
        st.divider()
    
    # Existing individual pattern testing
    if st.session_state.generated_patterns:
        st.subheader("Test Individual Patterns")
        
        # Select pattern to test
        pattern_options = [f"Pattern {i+1}: {p['type']}" for i, p in enumerate(st.session_state.generated_patterns)]
        selected_pattern_idx = st.selectbox("Select pattern to test:", range(len(pattern_options)), format_func=lambda x: pattern_options[x])
        
        selected_pattern = st.session_state.generated_patterns[selected_pattern_idx]['pattern']
        
        # Test text input
        test_text = st.text_area(
            "Enter test text:",
            height=100,
            placeholder="Enter text to test the regex pattern against...",
            key="test_individual"
        )
        
        if test_text.strip():
            try:
                # Compile and test the regex
                regex = re.compile(selected_pattern)
                matches = list(regex.finditer(test_text))
                
                col_test1, col_test2 = st.columns([1, 1])
                
                with col_test1:
                    st.subheader("Results")
                    st.metric("Matches Found", len(matches))
                    
                    if matches:
                        st.success("✅ Pattern matches found!")
                        
                        # Display matches
                        matches_data = []
                        for i, match in enumerate(matches):
                            matches_data.append({
                                "Match #": i + 1,
                                "Text": match.group(),
                                "Start": match.start(),
                                "End": match.end()
                            })
                        
                        df_matches = pd.DataFrame(matches_data)
                        st.dataframe(df_matches, use_container_width=True)
                    else:
                        st.warning("❌ No matches found")
                
                with col_test2:
                    st.subheader("Highlighted Text")
                    if matches:
                        # Create highlighted version of text
                        highlighted_text = test_text
                        offset = 0
                        
                        for match in matches:
                            start = match.start() + offset
                            end = match.end() + offset
                            match_text = match.group()
                            highlighted_match = f"**[{match_text}]**"
                            
                            highlighted_text = (
                                highlighted_text[:start] + 
                                highlighted_match + 
                                highlighted_text[end:]
                            )
                            offset += len(highlighted_match) - len(match_text)
                        
                        st.markdown(highlighted_text)
                    else:
                        st.write(test_text)
                        
            except re.error as e:
                st.error(f"Invalid regex pattern: {str(e)}")
            except Exception as e:
                st.error(f"Error testing pattern: {str(e)}")
    else:
        st.info("No patterns available for testing. Generate patterns first in the Manual Input or Excel Processing tabs.")

def additional_tools_section():
    """Additional tools and utilities"""
    st.header("🔧 Additional Tools")
    
    # Regex validation tool
    st.subheader("Regex Validator")
    regex_to_validate = st.text_input(
        "Enter regex pattern to validate:",
        placeholder="Enter your regex pattern here..."
    )
    
    if regex_to_validate:
        try:
            re.compile(regex_to_validate)
            st.success("✅ Valid regex pattern!")
            
            # Show basic pattern info
            col_info1, col_info2 = st.columns(2)
            with col_info1:
                st.metric("Pattern Length", len(regex_to_validate))
            with col_info2:
                flags_used = []
                if '(?i)' in regex_to_validate:
                    flags_used.append('Case Insensitive')
                if '(?m)' in regex_to_validate:
                    flags_used.append('Multiline')
                if '(?s)' in regex_to_validate:
                    flags_used.append('Dotall')
                
                st.write(f"**Flags:** {', '.join(flags_used) if flags_used else 'None'}")
                
        except re.error as e:
            st.error(f"❌ Invalid regex: {str(e)}")
    
    st.divider()
    
    # Pattern library
    st.subheader("📚 Common Pattern Library")
    
    common_patterns = {
        "Email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "Phone (US)": r'(\+?1[-.\s]?)?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})',
        "URL": r'https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?',
        "IP Address": r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b',
        "Date (MM/DD/YYYY)": r'\b\d{1,2}/\d{1,2}/\d{4}\b',
        "Currency Amount": r'\$\d+(?:,\d{3})*(?:\.\d{2})?',
        "Flight Code": r'[A-Z]{2,3}\d{3,4}[A-Z]?',
        "Time (24h)": r'\b([01]?[0-9]|2[0-3]):[0-5][0-9]\b'
    }
    
    selected_pattern = st.selectbox("Select a common pattern:", list(common_patterns.keys()))
    
    if selected_pattern:
        pattern = common_patterns[selected_pattern]
        st.code(pattern, language='regex')
        
        if st.button(f"📋 Copy {selected_pattern} Pattern", key=f"copy_common_{selected_pattern}"):
            st.success(f"Pattern for {selected_pattern} copied!")
            st.code(pattern, language='regex')

if __name__ == "__main__":
    main()
