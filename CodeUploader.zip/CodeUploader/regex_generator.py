import re
import pandas as pd
import tempfile
import os
from phrase_to_regex import phrase_to_regex
from fare_rule_matcher import FareRuleMatcher

class RegexGenerator:
    def __init__(self):
        self.matcher = FareRuleMatcher()
        self.common_patterns = {
            'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'phone': r'(\+?1[-.\s]?)?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})',
            'url': r'https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?',
            'ip_address': r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b',
            'date': r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b'
        }
    
    def generate_patterns(self, phrases, pattern_type="Auto-detect", case_sensitive=False, match_whole_word=False):
        """Generate regex patterns for a list of phrases"""
        patterns = []
        
        for phrase in phrases:
            if not phrase or phrase.strip() == "":
                continue
                
            pattern_info = self._generate_single_pattern(phrase, pattern_type, case_sensitive, match_whole_word)
            patterns.append(pattern_info)
        
        return patterns
    
    def _generate_single_pattern(self, phrase, pattern_type, case_sensitive, match_whole_word):
        """Generate a single regex pattern for a phrase"""
        try:
            # Detect pattern type if auto-detect is selected
            if pattern_type == "Auto-detect":
                detected_type = self._detect_pattern_type(phrase)
            else:
                detected_type = pattern_type.lower().replace(' ', '_')
            
            # Generate pattern based on type
            if detected_type in self.common_patterns:
                pattern = self.common_patterns[detected_type]
                explanation = f"Standard {detected_type} pattern"
            elif detected_type == "advanced_airline":
                pattern = self._generate_airline_pattern(phrase)
                explanation = "Advanced airline fare rule pattern"
            else:
                # Use the enhanced phrase_to_regex function
                pattern = phrase_to_regex(phrase)
                explanation = "Custom pattern generated from phrase"
            
            # Apply case sensitivity and word boundary options
            if not case_sensitive and pattern and not pattern.startswith('(?i)'):
                pattern = f"(?i){pattern}"
            
            if match_whole_word and pattern and not pattern.startswith(r'\b') and not pattern.endswith(r'\b'):
                pattern = f"\\b{pattern}\\b"
            
            # Validate the pattern
            is_valid, validation_message = self._validate_pattern(pattern)
            
            return {
                'pattern': pattern,
                'type': detected_type.replace('_', ' ').title(),
                'explanation': explanation,
                'confidence': self._calculate_confidence(phrase, detected_type),
                'valid': is_valid,
                'validation_message': validation_message
            }
            
        except Exception as e:
            return {
                'pattern': f"Error: {str(e)}",
                'type': 'Error',
                'explanation': f"Failed to generate pattern: {str(e)}",
                'confidence': 0.0,
                'valid': False,
                'validation_message': str(e)
            }
    
    def _detect_pattern_type(self, phrase):
        """Detect the most likely pattern type for a phrase"""
        phrase_lower = phrase.lower()
        
        # Check for common patterns
        if '@' in phrase and '.' in phrase.split('@')[-1]:
            return 'email'
        elif re.search(r'\+?[\d\s\-\(\)]{10,}', phrase):
            return 'phone'
        elif phrase.startswith(('http://', 'https://', 'www.')):
            return 'url'
        elif re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', phrase):
            return 'ip_address'
        elif re.search(r'\d{1,2}[/-]\d{1,2}[/-]\d{2,4}', phrase):
            return 'date'
        else:
            # Check if it matches airline patterns
            airline_match, _ = self.matcher.match_rule(phrase)
            if airline_match:
                return 'advanced_airline'
            else:
                return 'custom'
    
    def _generate_airline_pattern(self, phrase):
        """Generate airline-specific patterns"""
        return self.matcher.generate_flexible_pattern(phrase)
    
    def _validate_pattern(self, pattern):
        """Validate that the regex pattern is valid"""
        try:
            re.compile(pattern)
            return True, "Pattern is valid"
        except re.error as e:
            return False, f"Invalid regex: {str(e)}"
    
    def _calculate_confidence(self, phrase, pattern_type):
        """Calculate confidence score for the generated pattern"""
        base_confidence = 0.8
        
        # Adjust confidence based on pattern type and phrase characteristics
        if pattern_type in ['email', 'phone', 'url', 'ip_address']:
            return 0.95
        elif pattern_type == 'date':
            return 0.9
        elif pattern_type == 'advanced_airline':
            return 0.85
        else:
            # Custom patterns - confidence based on phrase complexity
            if len(phrase.split()) > 3:
                return base_confidence - 0.1
            else:
                return base_confidence
    
    def process_excel_file(self, file_path):
        """Process an Excel file and generate regex patterns for each phrase"""
        try:
            # Read the Excel file
            df = pd.read_excel(file_path)
            
            if df.empty:
                raise ValueError("The Excel file is empty")
            
            # Get the first column (assuming it contains phrases)
            first_col = df.columns[0]
            phrases_series = df[first_col]
            
            # Initialize result lists with proper length
            total_rows = len(df)
            generated_regex = [''] * total_rows
            pattern_types = [''] * total_rows  
            confidences = [0.0] * total_rows
            
            # Process each phrase
            for i in df.index:
                phrase = phrases_series.iloc[i] if i < len(phrases_series) else None
                
                if pd.isna(phrase) or (phrase is not None and str(phrase).strip() == ''):
                    generated_regex[i] = ''
                    pattern_types[i] = 'Empty'
                    confidences[i] = 0.0
                else:
                    try:
                        phrase_str = str(phrase).strip()
                        pattern_info = self._generate_single_pattern(phrase_str, "Auto-detect", False, False)
                        
                        generated_regex[i] = pattern_info['pattern']
                        pattern_types[i] = pattern_info['type']
                        confidences[i] = pattern_info['confidence']
                        
                    except Exception as e:
                        generated_regex[i] = f'Error: {str(e)}'
                        pattern_types[i] = 'Error'
                        confidences[i] = 0.0
            
            # Add new columns to the dataframe
            df['Generated_Regex'] = generated_regex
            df['Pattern_Type'] = pattern_types
            df['Confidence'] = confidences
            
            return df
            
        except Exception as e:
            raise Exception(f"Error processing Excel file: {str(e)}")
    
    def combine_regex_patterns(self, df, regex_column='Generated_Regex'):
        """Combine all valid regex patterns into a single comprehensive regex - optimized version"""
        try:
            if regex_column not in df.columns:
                raise ValueError(f"Column '{regex_column}' not found in dataframe")
            
            # Extract valid patterns with simplified processing
            valid_patterns = []
            
            for i, row in df.iterrows():
                pattern = row[regex_column]
                pattern_type = row.get('Pattern_Type', 'Unknown')
                
                # Quick validation - skip obviously invalid patterns
                if (pd.isna(pattern) or 
                    not isinstance(pattern, str) or
                    pattern.strip() == '' or 
                    pattern.startswith('Error:') or
                    pattern_type in ['Error', 'Empty']):
                    continue
                
                # Clean pattern quickly
                clean_pattern = self._clean_pattern_for_combination(pattern)
                if clean_pattern and len(clean_pattern) > 0:
                    valid_patterns.append(clean_pattern)
                
                # Limit to prevent performance issues
                if len(valid_patterns) >= 50:  # Cap at 50 patterns
                    break
            
            if not valid_patterns:
                raise ValueError("No valid patterns found to combine")
            
            # Create simple combined pattern
            combined_pattern = '(?i)(?:' + ')|(?:'.join(valid_patterns) + ')'
            
            # Validate the combined pattern
            try:
                re.compile(combined_pattern)
            except re.error as e:
                # If combination fails, try simpler approach
                combined_pattern = '(?i)' + '|'.join(f'(?:{p})' for p in valid_patterns[:10])  # Limit to first 10
            
            # Create minimal summary
            summary_df = pd.DataFrame({
                'Combined_Regex': [combined_pattern],
                'Total_Patterns_Combined': [len(valid_patterns)],
                'Generation_Timestamp': [pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')]
            })
            
            return {
                'combined_pattern': combined_pattern,
                'summary_df': summary_df,
                'breakdown_df': pd.DataFrame(),  # Skip breakdown to improve performance
                'pattern_count': len(valid_patterns),
                'success': True,
                'message': f'Successfully combined {len(valid_patterns)} patterns'
            }
            
        except Exception as e:
            return {
                'combined_pattern': None,
                'summary_df': pd.DataFrame(),
                'breakdown_df': pd.DataFrame(),
                'pattern_count': 0,
                'success': False,
                'message': f'Error combining patterns: {str(e)}'
            }
    
    def _clean_pattern_for_combination(self, pattern):
        """Clean pattern for combination by removing anchors and flags - simplified version"""
        try:
            if not pattern or len(pattern) == 0:
                return None
                
            # Simple cleaning - just remove common prefixes/suffixes
            cleaned = str(pattern)
            
            # Remove case-insensitive flag at start
            if cleaned.startswith('(?i)'):
                cleaned = cleaned[4:]
            
            # Remove anchors
            if cleaned.startswith('^'):
                cleaned = cleaned[1:]
            if cleaned.endswith('$'):
                cleaned = cleaned[:-1]
            
            # Remove whitespace patterns at start/end
            if cleaned.startswith('\\s*'):
                cleaned = cleaned[3:]
            if cleaned.endswith('\\s*'):
                cleaned = cleaned[:-3]
            
            # Basic validation
            if len(cleaned.strip()) < 3:  # Too short
                return None
                
            return cleaned.strip()
            
        except Exception:
            # If anything fails, return the original pattern
            return str(pattern) if pattern else None
    
    def _create_combined_pattern(self, patterns):
        """Create the final combined pattern with proper structure"""
        # Wrap each pattern in non-capturing group
        grouped_patterns = [f'(?:{pattern})' for pattern in patterns]
        
        # Join with OR operator
        combined_core = '|'.join(grouped_patterns)
        
        # Add case-insensitive flag and flexible anchoring
        final_pattern = f'(?i)^\\s*(?:{combined_core})\\s*$'
        
        return final_pattern
    
    def _get_pattern_type_summary(self, pattern_sources):
        """Get summary of pattern types included in combination"""
        type_counts = {}
        for source in pattern_sources:
            pattern_type = source['type']
            type_counts[pattern_type] = type_counts.get(pattern_type, 0) + 1
        
        summary_parts = []
        for pattern_type, count in sorted(type_counts.items()):
            summary_parts.append(f"{pattern_type}: {count}")
        
        return '; '.join(summary_parts)
    
    def process_and_combine_regex(self, file_path, sheet=0, regex_col='Generated_Regex'):
        """
        Combines all regex patterns from a column into a single pattern.
        Adds it to a new sheet in the same Excel file.

        Args:
            file_path (str): Path to the Excel file.
            sheet (int|str): Sheet index or name to read.
            regex_col (str): Column name containing regex patterns.

        Returns:
            str: Combined regex pattern.
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        # Read the input sheet
        df = pd.read_excel(file_path, sheet_name=sheet)

        if regex_col not in df.columns:
            raise ValueError(f"Column '{regex_col}' not found in sheet.")

        # Clean and collect non-empty regex strings, removing flags
        regex_list = []
        for r in df[regex_col]:
            if pd.notna(r) and str(r).strip() and not str(r).startswith('Error:'):
                cleaned_pattern = self._clean_pattern_for_combination(str(r).strip())
                if cleaned_pattern:
                    regex_list.append(cleaned_pattern)

        if not regex_list:
            raise ValueError("No valid regex patterns found.")

        # Combine with non-capturing groups and add case-insensitive flag
        combined_regex = '(?i)' + '|'.join(f'(?:{r})' for r in regex_list)

        # Create a new DataFrame and save
        combined_df = pd.DataFrame({'Combined_Regex': [combined_regex]})
        
        # Read existing sheets to preserve them
        with pd.ExcelFile(file_path) as xls:
            existing_sheets = {}
            for sheet_name in xls.sheet_names:
                existing_sheets[sheet_name] = pd.read_excel(xls, sheet_name=sheet_name)
        
        # Write back with new CombinedRegex sheet
        with pd.ExcelWriter(file_path, engine='openpyxl', mode='w') as writer:
            # Preserve existing sheets
            for sheet_name, sheet_df in existing_sheets.items():
                sheet_df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            # Add the combined regex sheet
            combined_df.to_excel(writer, sheet_name='CombinedRegex', index=False)

        print("✅ Combined regex written to 'CombinedRegex' sheet.")
        return combined_regex
    
    def save_combined_regex_to_excel(self, original_file_path, combined_data):
        """Save combined regex data to a new 'CombinedRegex' sheet in the original Excel file"""
        try:
            # Use the same file path to modify the existing file
            combined_pattern = combined_data['combined_pattern']
            
            # Create a simple DataFrame with just the combined regex
            combined_df = pd.DataFrame({'Combined_Regex': [combined_pattern]})
            
            # Read existing file and add new sheet
            with pd.ExcelFile(original_file_path) as xls:
                # Get all existing sheets
                existing_sheets = {}
                for sheet_name in xls.sheet_names:
                    existing_sheets[sheet_name] = pd.read_excel(xls, sheet_name=sheet_name)
            
            # Write back to same file with new sheet
            with pd.ExcelWriter(original_file_path, engine='openpyxl', mode='w') as writer:
                # Write existing sheets (preserve original names)
                for sheet_name, df in existing_sheets.items():
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
                
                # Add the new CombinedRegex sheet
                combined_df.to_excel(writer, sheet_name='CombinedRegex', index=False)
            
            return {
                'success': True,
                'filename': original_file_path,
                'message': f'Combined regex added to CombinedRegex sheet in the same file'
            }
            
        except Exception as e:
            return {
                'success': False,
                'filename': None,
                'message': f'Error saving combined regex: {str(e)}'
            }
