# Regex Pattern Generator

## Overview

This is a Streamlit-based web application designed to generate and test regular expression patterns from user input phrases. The application specializes in creating flexible regex patterns with advanced support for airline fare rule processing, featuring automated pattern detection, bulk Excel processing, and real-time pattern testing capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modular, single-tier architecture built entirely in Python:

**Frontend**: Streamlit web interface providing a tabbed user experience with real-time pattern generation and testing capabilities.

**Core Engine**: Python-based regex generation system with specialized modules for different pattern types and airline industry requirements.

**File Processing**: Built-in Excel file upload and processing capabilities for bulk pattern generation.

The architecture prioritizes simplicity and modularity, making it easy to extend with new pattern types and maintain existing functionality.

## Key Components

### 1. Main Application Interface (`app.py`)
- **Purpose**: Streamlit web interface orchestrating all user interactions
- **Key Features**:
  - Multi-tab interface (Manual Input, Excel Processing, Pattern Testing, Additional Tools)
  - Session state management for pattern history
  - Two-column layout for generation and testing
  - Real-time pattern validation and testing

### 2. Core Regex Generation Engine (`regex_generator.py`)
- **Purpose**: Central pattern generation logic with extensible architecture
- **Key Features**:
  - Pre-defined common patterns (email, phone, URL, IP address, date)
  - Auto-detection of pattern types from input analysis
  - Advanced airline-specific pattern generation
  - Pattern validation and confidence scoring
  - Support for case sensitivity and word boundary options

### 3. Airline Fare Rule Matcher (`fare_rule_matcher.py`)
- **Purpose**: Specialized component for airline industry text processing
- **Key Features**:
  - Pre-defined rule categories (Refund, Change, Penalty, Stopover, Validity, Ticket, Discount, Flight policies)
  - Pattern matching for fare rule identification
  - Flexible pattern generation for airline-specific terminology

### 4. Advanced Phrase Processing (`phrase_to_regex.py`)
- **Purpose**: Comprehensive text-to-regex conversion with enterprise-grade pattern handling
- **Key Features**:
  - Intelligent word type detection (currency codes, numbers, flight codes, dates)
  - Flexible pattern generation for compound words and airline terminology
  - Case-insensitive pattern creation with optional anchoring
  - Special handling for plurals and common airline terms

## Data Flow

1. **Input Processing**: Users input phrases through manual entry or Excel upload
2. **Pattern Detection**: System analyzes input to determine pattern type (auto-detect or manual selection)
3. **Pattern Generation**: Core engine generates appropriate regex patterns based on detected/selected type
4. **Validation**: Generated patterns are validated for syntax correctness
5. **Testing**: Real-time testing interface allows users to verify patterns against sample text
6. **Export**: Results can be downloaded as Excel files for further use

## External Dependencies

### Core Dependencies
- **Streamlit**: Web application framework for the user interface
- **Pandas**: Data manipulation and Excel file processing
- **Python Standard Library**: `re` for regex operations, `tempfile` and `os` for file handling

### Pattern Specializations
- Custom airline fare rule processing (no external dependencies)
- Built-in common pattern library (email, phone, URL, IP, date patterns)

## Deployment Strategy

**Single-File Deployment**: The application is designed for simple deployment as a Streamlit app:

1. **Local Development**: Run with `streamlit run app.py`
2. **Cloud Deployment**: Compatible with Streamlit Cloud, Heroku, or similar platforms
3. **Container Deployment**: Can be containerized with minimal Docker configuration

**Architecture Benefits**:
- No database requirements (stateless design with session management)
- Minimal external dependencies for easy deployment
- Modular design allows for easy feature additions
- Self-contained processing engine requires no external services

**Scalability Considerations**:
- File processing handled in-memory (suitable for moderate file sizes)
- Session state management for user experience
- Extensible pattern library for adding new pattern types

## Recent Changes

### July 29, 2025 - Implemented Regex Pattern Combination Enhancement
**Major Feature Addition**: Added comprehensive regex pattern combination functionality that merges all valid patterns into a single comprehensive regex and saves it to a new Excel sheet.

**User Request**: "Keep everything fine just need to add one more requirement as it should create or add a sheet and upload the combined regex codes as per requirement mentioned and don't change the existing sheet name please."

**Implementation Details**:
- **New Method**: `process_and_combine_regex()` function matching exact user specification
- **Excel Integration**: Adds 'CombinedRegex' sheet to the same Excel file without altering existing sheets
- **Pattern Cleaning**: Automatically removes case flags and anchors from individual patterns for proper combination
- **Combination Logic**: Uses non-capturing groups with OR logic: `(?i)(?:pattern1)|(?:pattern2)|(?:pattern3)`
- **Streamlit Interface**: Added "Combine All Patterns" button and "Add Combined Pattern to Excel" functionality
- **Pattern Validation**: Excludes error patterns and empty values from combination

**Technical Features**:
- Function signature: `process_and_combine_regex(file_path, sheet=0, regex_col='Generated_Regex')`
- Preserves all existing sheets while adding new 'CombinedRegex' sheet
- Comprehensive testing with 100% success rate (4/4 test patterns match)
- Case-insensitive flag applied to entire combined pattern
- Proper regex syntax validation and compilation testing

**User Impact**: Users can now process Excel files, generate individual patterns, and automatically combine them into a single master regex pattern that matches any of the individual patterns. The combined pattern is saved directly to the same Excel file for easy access.