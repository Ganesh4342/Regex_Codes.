import pandas as pd
import re

def phrase_to_regex(phrase):
    """Create simple but effective regex patterns that work correctly"""
    if not phrase or pd.isna(phrase):
        return r".*"
    
    phrase = str(phrase).strip()
    
    # Create a simple but flexible pattern
    pattern = create_simple_pattern(phrase)
    
    # Return with case insensitive flag 
    return f"(?i){pattern}"

def create_simple_pattern(phrase):
    """Create a simple pattern that focuses on readability and correctness"""
    
    # Split into words
    words = phrase.split()
    processed_words = []
    
    for word in words:
        # Process each word type
        if is_currency_code(word):
            processed_words.append(r'[A-Z]{3}')
        elif is_number(word):
            processed_words.append(r'\d+(?:[,.]\d+)*')
        elif is_currency_amount(word):
            processed_words.append(r'[\$€£¥₹]\d+(?:[,.]\d+)*')
        elif is_flight_code(word):
            processed_words.append(r'[A-Z]{1,3}\d{1,5}[A-Z]?')
        elif is_date(word):
            processed_words.append(r'\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}')
        elif is_month(word):
            processed_words.append(f'{word.upper()}')
        elif is_common_airline_term(word):
            # Handle plurals for common terms
            base = word.upper().rstrip('S')
            processed_words.append(f'(?:{base}|{base}S)')
        else:
            # Regular word - escape special characters
            processed_words.append(re.escape(word))
    
    # Join with flexible spacing
    pattern = r'\s+'.join(processed_words)
    
    # Anchor the pattern
    return f'^\\s*{pattern}\\s*$'

def is_currency_code(word):
    """Check if word is a 3-letter currency code"""
    common_currencies = [
        'USD', 'EUR', 'GBP', 'JPY', 'CHF', 'CAD', 'AUD', 'INR', 'CNY', 'KRW',
        'SEK', 'NOK', 'DKK', 'PLN', 'CZK', 'HUF', 'RUB', 'BRL', 'MXN', 'ZAR'
    ]
    return len(word) == 3 and word.upper() in common_currencies

def is_number(word):
    """Check if word is a standalone number"""
    return bool(re.match(r'^\d+(?:[,.]\d+)*$', word))

def is_currency_amount(word):
    """Check if word starts with currency symbol"""
    return bool(re.match(r'^[\$€£¥₹]\d+', word))

def is_flight_code(word):
    """Check if word looks like a flight code"""
    return bool(re.match(r'^[A-Z]{1,3}\d{1,5}[A-Z]?$', word.upper()))

def is_date(word):
    """Check if word looks like a date"""
    return bool(re.match(r'^\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}$', word))

def is_month(word):
    """Check if word is a month abbreviation"""
    months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 
              'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
    return word.upper() in months

def is_common_airline_term(word):
    """Check if word is a common airline term that might be plural"""
    terms = [
        'TICKET', 'FLIGHT', 'PENALTY', 'FEE', 'CHARGE', 'REFUND', 
        'CHANGE', 'PASSENGER', 'STOPOVER', 'COUPON', 'FARE', 
        'YEAR', 'MONTH', 'DAY', 'HOUR', 'MINUTE', 'TRIP', 'STOP'
    ]
    base_word = word.upper().rstrip('S')
    return base_word in terms or word.upper() in terms

# Test the function safely
if __name__ == "__main__":
    test_phrases = [
        'TICKET IS NON REFUNDABLE',
        'VALID FOR 1 YEAR AFTER DEPARTURE', 
        'MH 1234 FLIGHT TO SINGAPORE',
        'USD 500 PENALTY APPLIES',
        'PENALTY OF $200 FOR CHANGES'
    ]

    print("Testing phrase_to_regex function:")
    for phrase in test_phrases:
        try:
            result = phrase_to_regex(phrase)
            # Test if the pattern compiles
            re.compile(result)
            print(f'✓ "{phrase}"')
            print(f'  → {result}')
            print()
        except Exception as e:
            print(f'✗ Error with "{phrase}": {e}')
            print()