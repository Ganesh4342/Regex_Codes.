#!/usr/bin/env python3
"""
Test script to verify Excel processing functionality
"""

import pandas as pd
import tempfile
import os
from regex_generator import RegexGenerator

def create_test_excel():
    """Create a test Excel file with sample phrases"""
    test_data = {
        'Phrases': [
            'TICKET IS NON REFUNDABLE',
            'USD 500 PENALTY APPLIES', 
            'VALID FOR 1 YEAR AFTER DEPARTURE',
            'MH 1234 FLIGHT TO SINGAPORE',
            'PENALTY OF $200 FOR CHANGES',
            'hello@example.com',
            '+1-555-123-4567',
            '192.168.1.1',
            '12/25/2024',
            '',  # Empty value
            'Flight AA123 departs at 14:30',
            'Refund EUR 750.50 within 24 hours'
        ]
    }
    
    df = pd.DataFrame(test_data)
    
    # Create temporary Excel file
    with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp_file:
        df.to_excel(tmp_file.name, index=False)
        return tmp_file.name

def test_excel_processing():
    """Test the Excel processing functionality"""
    print("Creating test Excel file...")
    test_file = create_test_excel()
    
    try:
        print("Processing Excel file...")
        generator = RegexGenerator()
        result_df = generator.process_excel_file(test_file)
        
        print(f"✓ Successfully processed {len(result_df)} rows")
        print(f"✓ Generated {len(result_df['Generated_Regex'])} patterns")
        
        # Display sample results
        print("\nSample Results:")
        print("=" * 80)
        for i, row in result_df.head(5).iterrows():
            phrase = row['Phrases']
            pattern = row['Generated_Regex']
            pattern_type = row['Pattern_Type']
            confidence = row['Confidence']
            
            print(f"Phrase: {phrase}")
            print(f"Pattern: {pattern}")
            print(f"Type: {pattern_type}, Confidence: {confidence:.1%}")
            print("-" * 40)
        
        # Check for any errors
        error_count = len(result_df[result_df['Pattern_Type'] == 'Error'])
        empty_count = len(result_df[result_df['Pattern_Type'] == 'Empty'])
        
        print(f"\nSummary:")
        print(f"✓ Total phrases processed: {len(result_df)}")
        print(f"✓ Successful patterns: {len(result_df) - error_count - empty_count}")
        print(f"• Empty phrases: {empty_count}")
        print(f"• Errors: {error_count}")
        
        if error_count > 0:
            print("\nErrors found:")
            error_rows = result_df[result_df['Pattern_Type'] == 'Error']
            for i, row in error_rows.iterrows():
                print(f"- {row['Phrases']}: {row['Generated_Regex']}")
        
        return True
        
    except Exception as e:
        print(f"✗ Test failed: {str(e)}")
        return False
    
    finally:
        # Clean up temporary file
        if os.path.exists(test_file):
            os.unlink(test_file)

if __name__ == "__main__":
    print("Testing Excel Processing Functionality")
    print("=" * 50)
    
    success = test_excel_processing()
    
    if success:
        print("\n✓ All tests passed! Excel processing is working correctly.")
    else:
        print("\n✗ Tests failed. Check the error messages above.")