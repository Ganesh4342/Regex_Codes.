#!/usr/bin/env python3
"""
Test script to validate generated regex patterns work correctly
"""

import re
from regex_generator import RegexGenerator

def test_regex_patterns():
    """Test various patterns to ensure they work correctly"""
    
    # Test phrases similar to what was shown in the regex101 screenshot
    test_cases = [
        {
            'phrase': 'STOPOVERS STOPOVERS FROM TO MIA FOR ROUND TRIP SUPER INSTANT PURCHASE',
            'test_strings': [
                'stopovers stopovers from to mia for round trip super instant purchase',
                'STOPOVERS STOPOVERS FROM TO MIA FOR ROUND TRIP SUPER INSTANT PURCHASE',
                'Stopovers Stopovers From To Mia For Round Trip Super Instant Purchase'
            ]
        },
        {
            'phrase': 'USD 500 PENALTY APPLIES', 
            'test_strings': [
                'USD 500 PENALTY APPLIES',
                'usd 500 penalty applies',
                'EUR 750 penalty applies'
            ]
        },
        {
            'phrase': 'TICKET IS NON REFUNDABLE',
            'test_strings': [
                'TICKET IS NON REFUNDABLE',
                'ticket is non refundable',
                'TICKETS IS NON REFUNDABLE'
            ]
        }
    ]
    
    generator = RegexGenerator()
    
    print("Testing Regex Pattern Validity")
    print("=" * 60)
    
    for i, test_case in enumerate(test_cases, 1):
        phrase = test_case['phrase']
        test_strings = test_case['test_strings']
        
        print(f"\nTest Case {i}: {phrase}")
        print("-" * 40)
        
        try:
            # Generate pattern
            pattern_info = generator._generate_single_pattern(phrase, "Auto-detect", False, False)
            pattern = pattern_info['pattern']
            
            print(f"Generated Pattern: {pattern}")
            print(f"Pattern Length: {len(pattern)} characters")
            
            # Test compilation
            try:
                regex = re.compile(pattern)
                print("✓ Pattern compiles successfully")
            except re.error as e:
                print(f"✗ Pattern compilation error: {e}")
                continue
            
            # Test matching
            print("\nMatching Tests:")
            for test_string in test_strings:
                try:
                    match = regex.search(test_string)
                    if match:
                        print(f"  ✓ '{test_string}' → MATCHES")
                    else:
                        print(f"  - '{test_string}' → no match")
                except Exception as e:
                    print(f"  ✗ Error testing '{test_string}': {e}")
            
        except Exception as e:
            print(f"✗ Error generating pattern: {e}")
    
    print("\n" + "=" * 60)
    print("Pattern validation complete!")

def show_simple_examples():
    """Show simple, clean examples for regex101 testing"""
    
    print("\nSimple Examples for regex101.com Testing:")
    print("=" * 50)
    
    simple_phrases = [
        "USD 500 PENALTY",
        "FLIGHT AA123", 
        "TICKET REFUNDABLE",
        "VALID 1 YEAR"
    ]
    
    generator = RegexGenerator()
    
    for phrase in simple_phrases:
        try:
            pattern_info = generator._generate_single_pattern(phrase, "Auto-detect", False, False)
            pattern = pattern_info['pattern']
            
            print(f"\nPhrase: {phrase}")
            print(f"Pattern: {pattern}")
            
            # Test with the phrase itself
            regex = re.compile(pattern)
            if regex.search(phrase):
                print("✓ Self-test passes")
            else:
                print("✗ Self-test fails")
                
        except Exception as e:
            print(f"✗ Error: {e}")

if __name__ == "__main__":
    test_regex_patterns()
    show_simple_examples()