import streamlit as st
import re
import pandas as pd
import tempfile
import os
from regex_generator import RegexGenerator

# Configure page
st.set_page_config(
    page_title="Regex Pattern Generator",
    page_icon="🔍",
    layout="wide"
)

# Initialize session state
if 'generated_patterns' not in st.session_state:
    st.session_state.generated_patterns = []

def main():
    """Main application function"""
    st.title("🔍 Regex Pattern Generator")
    st.markdown("Generate and test regular expression patterns from phrases with advanced airline fare rule support")
    
    # Create tabs for different functionalities
    tab1, tab2, tab3, tab4 = st.tabs(["Manual Input", "Excel Processing", "Pattern Testing", "Additional Tools"])
    
    with tab1:
        manual_input_interface()
    
    with tab2:
        excel_upload_interface()
    
    with tab3:
        pattern_testing_section()
    
    with tab4:
        additional_tools_section()

def manual_input_interface():
    """Interface for manual phrase input"""
    # Create two columns for layout
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.header("Pattern Generation")
        
        # Input for phrases
        phrases_input = st.text_area(
            "Enter phrases (one per line):",
            height=150,
            placeholder="Enter your phrases here...\nExample:\nhello@example.com\ntest@domain.org\n+1-555-123-4567"
        )
        
        # Pattern type selection
        pattern_type = st.selectbox(
            "Pattern Type:",
            ["Auto-detect", "Email", "Phone Number", "URL", "Date", "IP Address", "Advanced Airline", "Custom"]
        )
        
        # Generation options
        st.subheader("Options")
        case_sensitive = st.checkbox("Case Sensitive", value=False)
        match_whole_word = st.checkbox("Match Whole Words", value=False)
        
        # Generate button
        if st.button("Generate Regex Pattern", type="primary", key="manual_generate"):
            if phrases_input.strip():
                phrases = [p.strip() for p in phrases_input.split('\n') if p.strip()]
                generator = RegexGenerator()
                
                try:
                    # Generate regex patterns
                    patterns = generator.generate_patterns(
                        phrases, 
                        pattern_type, 
                        case_sensitive, 
                        match_whole_word
                    )
                    
                    st.session_state.generated_patterns = patterns
                    st.success(f"Generated {len(patterns)} pattern(s)!")
                    
                except Exception as e:
                    st.error(f"Error generating patterns: {str(e)}")
                    st.error(f"Debug info: Please check your input phrases for special characters")
            else:
                st.warning("Please enter some phrases to generate patterns.")
    
    with col2:
        display_generated_patterns()

def excel_upload_interface():
    """Interface for Excel file upload and processing"""
    st.header("Excel File Processing")
    
    # File upload
    uploaded_file = st.file_uploader(
        "Upload your Excel file",
        type=['xlsx', 'xls'],
        help="Upload an Excel file with phrases in the first column"
    )
    
    if uploaded_file is not None:
        if st.button("Process Uploaded File", type="primary"):
            try:
                # Save uploaded file temporarily
                with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp_file:
                    tmp_file.write(uploaded_file.getvalue())
                    tmp_file_path = tmp_file.name
                
                generator = RegexGenerator()
                df = generator.process_excel_file(tmp_file_path)
                
                st.session_state['processed_df'] = df
                st.success(f"Processed {len(df)} rows from the uploaded file!")
                
                # Clean up temporary file
                os.unlink(tmp_file_path)
                
            except Exception as e:
                st.error(f"Error processing uploaded file: {str(e)}")
                
                # Provide more specific error guidance
                error_msg = str(e).lower()
                if "length" in error_msg and "match" in error_msg:
                    st.error("📋 **Data Issue**: The Excel file has inconsistent row counts. This can happen when:")
                    st.write("• Some rows are completely empty")
                    st.write("• The file has merged cells") 
                    st.write("• There are hidden rows or formatting issues")
                    st.write("**Solution**: Try saving your Excel file as a new .xlsx file with only the data you need.")
                elif "empty" in error_msg:
                    st.error("📋 **Empty File**: The uploaded Excel file appears to be empty or has no data.")
                else:
                    st.error("📋 **General Guidance**: Please ensure your Excel file:")
                    st.write("• Has phrases in the first column")
                    st.write("• Is saved as .xlsx or .xls format")
                    st.write("• Contains actual text data (not just headers)")
                    st.write("• Has no merged cells or complex formatting")
    
    # Display processed data
    if 'processed_df' in st.session_state:
        df = st.session_state['processed_df']
        
        st.subheader("Processing Results")
        
        # Display summary statistics
        col_stats1, col_stats2, col_stats3 = st.columns(3)
        with col_stats1:
            st.metric("Total Phrases", len(df))
        with col_stats2:
            pattern_types = df['Pattern_Type'].value_counts()
            st.metric("Pattern Types", len(pattern_types))
        with col_stats3:
            avg_confidence = df['Confidence'].mean()
            st.metric("Avg Confidence", f"{avg_confidence:.1%}")
        
        # Display sample results
        st.subheader("Sample Enhanced Patterns")
        
        # Determine which regex column to use
        regex_col = 'Generated_Regex' if 'Generated_Regex' in df.columns else 'Updated_Regex'
        
        # Show first 10 results
        display_cols = [df.columns[0], regex_col, 'Pattern_Type', 'Confidence'] 
        sample_df = df.head(10)[display_cols].copy()
        
        # Truncate long text for better display
        for col in [df.columns[0], regex_col]:
            if col in sample_df.columns:
                sample_df[col] = sample_df[col].astype(str).str[:80] + "..."
        
        st.dataframe(sample_df, use_container_width=True)
        
        # Download button for processed file
        if st.button("📥 Download Enhanced Excel File"):
            try:
                output_filename = "Enhanced_Regex_Patterns.xlsx"
                df.to_excel(output_filename, index=False)
                
                with open(output_filename, "rb") as file:
                    st.download_button(
                        label="Download Excel file",
                        data=file.read(),
                        file_name=output_filename,
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )
            except Exception as e:
                st.error(f"Error creating download file: {str(e)}")
        
        # Display pattern type distribution
        if len(df) > 0:
            st.subheader("Pattern Type Distribution")
            pattern_counts = df['Pattern_Type'].value_counts()
            st.bar_chart(pattern_counts)

def display_generated_patterns():
    """Display generated patterns in a consistent format"""
    st.header("Generated Patterns")
    
    if st.session_state.generated_patterns:
        for i, pattern_info in enumerate(st.session_state.generated_patterns):
            with st.expander(f"Pattern {i+1}: {pattern_info['type']}", expanded=True):
                # Display the regex pattern
                st.code(pattern_info['pattern'], language='regex')
                
                # Copy button
                if st.button(f"📋 Copy Pattern {i+1}", key=f"copy_{i}"):
                    st.write("Pattern copied to clipboard!")
                    st.code(pattern_info['pattern'], language='regex')
                
                # Pattern explanation
                if pattern_info.get('explanation'):
                    st.write("**Explanation:**")
                    st.write(pattern_info['explanation'])
                
                # Confidence score and validity
                col_conf, col_valid = st.columns(2)
                with col_conf:
                    if pattern_info.get('confidence'):
                        st.metric("Confidence", f"{pattern_info['confidence']:.1%}")
                with col_valid:
                    if pattern_info.get('valid') is not None:
                        status = "✅ Valid" if pattern_info['valid'] else "❌ Invalid"
                        st.write(f"**Status:** {status}")
                        if not pattern_info['valid'] and pattern_info.get('validation_message'):
                            st.error(f"Error: {pattern_info['validation_message']}")
    else:
        st.info("No patterns generated yet. Enter some phrases and click 'Generate Regex Pattern'.")

def pattern_testing_section():
    """Pattern testing interface"""
    st.header("🧪 Pattern Testing")
    
    if st.session_state.generated_patterns:
        # Select pattern to test
        pattern_options = [f"Pattern {i+1}: {p['type']}" for i, p in enumerate(st.session_state.generated_patterns)]
        selected_pattern_idx = st.selectbox("Select pattern to test:", range(len(pattern_options)), format_func=lambda x: pattern_options[x])
        
        selected_pattern = st.session_state.generated_patterns[selected_pattern_idx]['pattern']
        
        # Test text input
        test_text = st.text_area(
            "Enter test text:",
            height=100,
            placeholder="Enter text to test the regex pattern against..."
        )
        
        if test_text.strip():
            try:
                # Compile and test the regex
                regex = re.compile(selected_pattern)
                matches = list(regex.finditer(test_text))
                
                col_test1, col_test2 = st.columns([1, 1])
                
                with col_test1:
                    st.subheader("Results")
                    st.metric("Matches Found", len(matches))
                    
                    if matches:
                        st.success("✅ Pattern matches found!")
                        
                        # Display matches
                        matches_data = []
                        for i, match in enumerate(matches):
                            matches_data.append({
                                "Match #": i + 1,
                                "Text": match.group(),
                                "Start": match.start(),
                                "End": match.end()
                            })
                        
                        df_matches = pd.DataFrame(matches_data)
                        st.dataframe(df_matches, use_container_width=True)
                    else:
                        st.warning("❌ No matches found")
                
                with col_test2:
                    st.subheader("Highlighted Text")
                    if matches:
                        # Create highlighted version of text
                        highlighted_text = test_text
                        offset = 0
                        
                        for match in matches:
                            start = match.start() + offset
                            end = match.end() + offset
                            match_text = match.group()
                            highlighted_match = f"**[{match_text}]**"
                            
                            highlighted_text = (
                                highlighted_text[:start] + 
                                highlighted_match + 
                                highlighted_text[end:]
                            )
                            offset += len(highlighted_match) - len(match_text)
                        
                        st.markdown(highlighted_text)
                    else:
                        st.write(test_text)
                        
            except re.error as e:
                st.error(f"Invalid regex pattern: {str(e)}")
            except Exception as e:
                st.error(f"Error testing pattern: {str(e)}")
    else:
        st.info("Generate a pattern first to test it.")

def additional_tools_section():
    """Additional tools and utilities"""
    st.header("🔧 Additional Tools")
    
    col_tools1, col_tools2 = st.columns([1, 1])
    
    with col_tools1:
        st.subheader("Pattern Validator")
        custom_pattern = st.text_input("Enter custom regex pattern to validate:")
        
        if custom_pattern:
            try:
                re.compile(custom_pattern)
                st.success("✅ Valid regex pattern")
                
                # Test the custom pattern
                test_input = st.text_input("Test the pattern:", key="custom_test")
                if test_input:
                    matches = re.findall(custom_pattern, test_input)
                    st.write(f"Matches found: {len(matches)}")
                    if matches:
                        st.write("Matches:")
                        for i, match in enumerate(matches):
                            st.write(f"{i+1}. {match}")
                            
            except re.error as e:
                st.error(f"❌ Invalid regex: {str(e)}")
    
    with col_tools2:
        st.subheader("Quick Patterns")
        quick_patterns = {
            "Email": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
            "Phone (US)": r"\+?1?[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}",
            "URL": r"https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:\w*))?)?",
            "Date (MM/DD/YYYY)": r"\d{1,2}/\d{1,2}/\d{4}",
            "IP Address": r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}",
            "Currency": r"[\$€£¥]\s?\d+(?:,\d{3})*(?:\.\d{2})?",
        }
        
        for name, pattern in quick_patterns.items():
            if st.button(f"Use {name} Pattern", key=f"quick_{name}"):
                st.code(pattern, language='regex')
                
        st.subheader("Pattern History")
        if st.button("Clear Pattern History"):
            st.session_state.generated_patterns = []
            st.success("Pattern history cleared!")

if __name__ == "__main__":
    main()
