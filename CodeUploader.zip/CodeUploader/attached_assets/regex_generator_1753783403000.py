import re
import pandas as pd
from typing import List, Dict, Any, Optional
from fare_rule_matcher import FareRuleMatcher
from phrase_to_regex import phrase_to_regex

class RegexGenerator:
    def __init__(self):
        self.fare_matcher = FareRuleMatcher()
        self.predefined_patterns = {
            'email': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            'phone': r'(\+?1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}',
            'url': r'https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:\w*))?)?',
            'ip_address': r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b',
            'date': r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{4}[/-]\d{1,2}[/-]\d{1,2}\b'
        }

    def generate_patterns(self, phrases: List[str], pattern_type: str = "Auto-detect", 
                         case_sensitive: bool = False, match_whole_word: bool = False) -> List[Dict[str, Any]]:
        """Generate regex patterns from a list of phrases"""
        patterns = []
        
        for phrase in phrases:
            if not phrase or not phrase.strip():
                continue
                
            try:
                pattern_info = self._generate_single_pattern(
                    phrase.strip(), pattern_type, case_sensitive, match_whole_word
                )
                if pattern_info:
                    patterns.append(pattern_info)
            except Exception as e:
                # Create error pattern info
                patterns.append({
                    'pattern': f'# Error: {str(e)}',
                    'type': 'Error',
                    'confidence': 0.0,
                    'valid': False,
                    'validation_message': str(e),
                    'explanation': f'Failed to generate pattern for: "{phrase}"'
                })
        
        return patterns

    def _generate_single_pattern(self, phrase: str, pattern_type: str, 
                                case_sensitive: bool, match_whole_word: bool) -> Dict[str, Any]:
        """Generate a single regex pattern"""
        
        if pattern_type == "Auto-detect":
            detected_type = self._detect_pattern_type(phrase)
            pattern_type = detected_type
        
        # Generate the appropriate pattern
        if pattern_type in self.predefined_patterns:
            pattern = self.predefined_patterns[pattern_type]
            explanation = f"Predefined {pattern_type} pattern"
            confidence = 0.9
        elif pattern_type == "Advanced Airline":
            pattern = self._generate_airline_pattern(phrase)
            explanation = "Advanced airline fare rule pattern with flexible matching"
            confidence = 0.8
        else:
            # Use comprehensive phrase processing
            pattern = self._process_phrase_comprehensive(phrase)
            explanation = "Comprehensive phrase pattern with flexible spacing and case handling"
            confidence = 0.7
        
        # Apply case sensitivity and word boundary options
        if not case_sensitive and not pattern.startswith('(?i)'):
            pattern = f'(?i){pattern}'
        
        if match_whole_word and not pattern.startswith(r'\b') and not pattern.endswith(r'\b'):
            pattern = f'\\b{pattern}\\b'
        
        # Validate the pattern
        is_valid, validation_message = self._validate_pattern(pattern)
        
        return {
            'pattern': pattern,
            'type': pattern_type,
            'confidence': confidence,
            'valid': is_valid,
            'validation_message': validation_message,
            'explanation': explanation
        }

    def _detect_pattern_type(self, phrase: str) -> str:
        """Detect the most likely pattern type for a phrase"""
        phrase_lower = phrase.lower()
        
        # Check for email patterns
        if '@' in phrase and '.' in phrase.split('@')[-1]:
            return 'email'
        
        # Check for phone patterns
        if re.search(r'[\d\-\(\)\s\+]{10,}', phrase):
            return 'phone'
        
        # Check for URL patterns
        if phrase_lower.startswith(('http', 'www', 'ftp')):
            return 'url'
        
        # Check for IP address patterns
        if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', phrase):
            return 'ip_address'
        
        # Check for date patterns
        if re.search(r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b', phrase):
            return 'date'
        
        # Check for airline-specific patterns
        airline_keywords = ['flight', 'fare', 'penalty', 'refund', 'ticket', 'passenger', 'usd', 'eur', 'gbp']
        if any(keyword in phrase_lower for keyword in airline_keywords):
            return 'Advanced Airline'
        
        return 'Custom'

    def _generate_airline_pattern(self, phrase: str) -> str:
        """Generate airline-specific pattern using fare rule matcher"""
        try:
            pattern = self.fare_matcher.generate_flexible_pattern(phrase)
            if pattern:
                return pattern
        except Exception as e:
            print(f"Airline pattern generation error: {e}")
        
        # Fallback to comprehensive processing
        return self._process_phrase_comprehensive(phrase)

    def _process_phrase_comprehensive(self, phrase: str) -> str:
        """Process phrase with comprehensive pattern generation"""
        try:
            return phrase_to_regex(phrase)
        except Exception as e:
            print(f"Comprehensive processing error: {e}")
            # Ultimate fallback - simple escape
            return re.escape(phrase)

    def _validate_pattern(self, pattern: str) -> tuple[bool, Optional[str]]:
        """Validate that a regex pattern is compilable"""
        try:
            re.compile(pattern)
            return True, None
        except re.error as e:
            return False, str(e)
        except Exception as e:
            return False, f"Unexpected error: {str(e)}"

    def process_excel_file(self, file_path: str) -> pd.DataFrame:
        """Process an Excel file and generate regex patterns for all phrases"""
        try:
            # Read the Excel file with error handling
            try:
                df = pd.read_excel(file_path)
            except Exception as e:
                raise ValueError(f"Cannot read Excel file: {str(e)}")
            
            if df.empty:
                raise ValueError("Excel file is empty or contains no data")
            
            # Get the first column (assuming it contains phrases)
            phrase_column = df.columns[0]
            
            # Create result lists with same length as original DataFrame
            generated_patterns = []
            pattern_types = []
            confidences = []
            
            # Process each row in the DataFrame
            for index in df.index:
                phrase_value = df.loc[index, phrase_column]
                
                # Handle NaN or empty values
                if pd.isna(phrase_value):
                    generated_patterns.append("# No phrase to process")
                    pattern_types.append("Empty")
                    confidences.append(0.0)
                    continue
                
                phrase_str = str(phrase_value).strip()
                if not phrase_str:
                    generated_patterns.append("# No phrase to process")
                    pattern_types.append("Empty")
                    confidences.append(0.0)
                    continue
                
                phrase = phrase_str
                
                try:
                    # Use auto-detect for Excel processing
                    pattern_info = self._generate_single_pattern(phrase, "Auto-detect", False, False)
                    generated_patterns.append(pattern_info['pattern'])
                    pattern_types.append(pattern_info['type'])
                    confidences.append(pattern_info['confidence'])
                except Exception as e:
                    generated_patterns.append(f"# Error: {str(e)}")
                    pattern_types.append("Error")
                    confidences.append(0.0)
            
            # Verify lengths match
            if len(generated_patterns) != len(df):
                raise ValueError(f"Data length mismatch: DataFrame has {len(df)} rows, but generated {len(generated_patterns)} patterns")
            
            # Create result DataFrame
            result_df = df.copy()
            result_df['Generated_Regex'] = generated_patterns
            result_df['Pattern_Type'] = pattern_types
            result_df['Confidence'] = confidences
            
            return result_df
            
        except Exception as e:
            raise Exception(f"Error processing Excel file: {str(e)}")

    def test_pattern(self, pattern: str, test_text: str) -> Dict[str, Any]:
        """Test a regex pattern against test text"""
        try:
            regex = re.compile(pattern)
            matches = list(regex.finditer(test_text))
            
            return {
                'matches': [match.group() for match in matches],
                'match_count': len(matches),
                'match_positions': [(match.start(), match.end()) for match in matches],
                'success': True,
                'error': None
            }
        except re.error as e:
            return {
                'matches': [],
                'match_count': 0,
                'match_positions': [],
                'success': False,
                'error': f"Regex error: {str(e)}"
            }
        except Exception as e:
            return {
                'matches': [],
                'match_count': 0,
                'match_positions': [],
                'success': False,
                'error': f"Unexpected error: {str(e)}"
            }
