import re
import pandas as pd

def phrase_to_regex_simple(phrase):
    """Create simple but effective regex patterns that work correctly"""
    if not phrase or pd.isna(phrase):
        return r".*"
    
    phrase = str(phrase).strip()
    
    # Create a simple but flexible pattern
    pattern = create_simple_pattern(phrase)
    
    # Return with case insensitive flag
    return f"(?i){pattern}"

def create_simple_pattern(phrase):
    """Create a simple pattern that focuses on readability and correctness"""
    
    # Split into words
    words = phrase.split()
    processed_words = []
    
    for word in words:
        # Process each word type
        if is_currency_code(word):
            processed_words.append(r'[A-Z]{3}')
        elif is_number(word):
            processed_words.append(r'\d+(?:[,.]\d+)*')
        elif is_currency_amount(word):
            processed_words.append(r'[\$€£¥₹]\d+(?:[,.]\d+)*')
        elif is_flight_code(word):
            processed_words.append(r'[A-Z]{1,3}\d{1,5}[A-Z]?')
        elif is_date(word):
            processed_words.append(r'\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}')
        elif is_month(word):
            processed_words.append(f'(?i:{word.upper()})')
        elif is_common_airline_term(word):
            # Handle plurals for common terms
            base = word.upper().rstrip('S')
            processed_words.append(f'(?i:{base}S?)')
        else:
            # Regular word - escape and make case insensitive
            escaped = re.escape(word)
            processed_words.append(f'(?i:{escaped})')
    
    # Join with flexible spacing
    pattern = r'\s*'.join(processed_words)
    
    # Anchor the pattern
    return f'^\\s*{pattern}\\s*$'

def is_currency_code(word):
    """Check if word is a 3-letter currency code"""
    return len(word) == 3 and word.isalpha() and word.upper() in [
        'USD', 'EUR', 'GBP', 'JPY', 'CHF', 'CAD', 'AUD', 'INR', 'CNY', 'KRW'
    ]

def is_number(word):
    """Check if word is a standalone number"""
    return bool(re.match(r'^\d+(?:[,.]\d+)*$', word))

def is_currency_amount(word):
    """Check if word starts with currency symbol"""
    return bool(re.match(r'^[\$€£¥₹]\d+', word))

def is_flight_code(word):
    """Check if word looks like a flight code"""
    return bool(re.match(r'^[A-Z]{1,3}\d{1,5}[A-Z]?$', word.upper()))

def is_date(word):
    """Check if word looks like a date"""
    return bool(re.match(r'^\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}$', word))

def is_month(word):
    """Check if word is a month abbreviation"""
    months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 
              'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
    return word.upper() in months

def is_common_airline_term(word):
    """Check if word is a common airline term that might be plural"""
    terms = [
        'TICKET', 'FLIGHT', 'PENALTY', 'FEE', 'CHARGE', 'REFUND', 
        'CHANGE', 'PASSENGER', 'STOPOVER', 'COUPON', 'FARE', 
        'YEAR', 'MONTH', 'DAY', 'HOUR', 'MINUTE'
    ]
    base_word = word.upper().rstrip('S')
    return base_word in terms or word.upper() in terms

# Test the simplified approach
if __name__ == "__main__":
    test_phrases = [
        "STOPOVERS STOPOVERS FROM TO MIA FOR ROUND TRIP SUPER INSTANT PURCHASE",
        "USD 500 PENALTY APPLIES",
        "TICKET IS NON REFUNDABLE", 
        "FLIGHT AA123 DEPARTURE",
        "VALID FOR 1 YEAR"
    ]
    
    print("Testing simplified regex generation:")
    print("=" * 60)
    
    for phrase in test_phrases:
        try:
            pattern = phrase_to_regex_simple(phrase)
            # Test compilation
            re.compile(pattern)
            print(f"✓ Phrase: {phrase}")
            print(f"  Pattern: {pattern}")
            print(f"  Length: {len(pattern)}")
            print()
        except Exception as e:
            print(f"✗ Error with '{phrase}': {e}")
            print()