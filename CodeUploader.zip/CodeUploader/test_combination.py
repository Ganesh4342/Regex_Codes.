#!/usr/bin/env python3
"""
Test script to verify the regex combination functionality
"""

import pandas as pd
import tempfile
import os
from regex_generator import RegexGenerator

def create_test_excel_for_combination():
    """Create a test Excel file with various phrase types for combination testing"""
    test_data = {
        'Phrases': [
            'TICKET IS NON REFUNDABLE',
            'USD 500 PENALTY APPLIES', 
            'VALID FOR 1 YEAR AFTER DEPARTURE',
            'MH 1234 FLIGHT TO SINGAPORE',
            'PENALTY OF $200 FOR CHANGES',
            'hello@example.com',
            '+1-555-123-4567',
            'Flight AA123 departs at 14:30',
            'Refund EUR 750.50 within 24 hours',
            'STOPOVER ALLOWED',
            'NO CHANGES PERMITTED',
            'INSTANT PURCHASE REQUIRED'
        ]
    }
    
    df = pd.DataFrame(test_data)
    
    # Create temporary Excel file
    with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp_file:
        df.to_excel(tmp_file.name, index=False)
        return tmp_file.name

def test_combination_functionality():
    """Test the complete workflow: process Excel → combine patterns → save results"""
    print("Testing Regex Combination Functionality")
    print("=" * 60)
    
    test_file = create_test_excel_for_combination()
    
    try:
        print("Step 1: Processing Excel file...")
        generator = RegexGenerator()
        df = generator.process_excel_file(test_file)
        
        print(f"✓ Successfully processed {len(df)} rows")
        print(f"✓ Generated regex patterns for all phrases")
        
        # Show sample patterns
        print("\nSample generated patterns:")
        for i, row in df.head(5).iterrows():
            phrase = row['Phrases']
            pattern = row['Generated_Regex']
            pattern_type = row['Pattern_Type']
            print(f"  {phrase} → {pattern_type}")
        
        print("\nStep 2: Combining all patterns...")
        combination_result = generator.combine_regex_patterns(df)
        
        if combination_result['success']:
            print(f"✓ Successfully combined {combination_result['pattern_count']} patterns")
            print(f"✓ {combination_result['message']}")
            
            combined_pattern = combination_result['combined_pattern']
            print(f"\nCombined Pattern (length: {len(combined_pattern)} chars):")
            print(f"{combined_pattern}")
            
            # Test the combined pattern
            print("\nStep 3: Testing combined pattern...")
            test_strings = [
                'TICKET IS NON REFUNDABLE',
                'USD 500 penalty applies',
                'hello@example.com',
                'Flight MH123',
                'STOPOVER ALLOWED'
            ]
            
            import re
            try:
                regex = re.compile(combined_pattern)
                matches_found = 0
                
                for test_string in test_strings:
                    if regex.search(test_string):
                        matches_found += 1
                        print(f"  ✓ '{test_string}' matches")
                    else:
                        print(f"  - '{test_string}' no match")
                
                print(f"\n✓ Combined pattern successfully matched {matches_found}/{len(test_strings)} test strings")
                
            except re.error as e:
                print(f"✗ Combined pattern compilation error: {e}")
                return False
            
            print("\nStep 4: Testing save functionality...")
            save_result = generator.save_combined_regex_to_excel(test_file, combination_result)
            
            if save_result['success']:
                print(f"✓ {save_result['message']}")
                
                # Verify the saved file
                if os.path.exists(save_result['filename']):
                    print(f"✓ Output file created: {save_result['filename']}")
                    
                    # Check the sheets
                    with pd.ExcelFile(save_result['filename']) as xls:
                        sheets = xls.sheet_names
                        print(f"✓ File contains {len(sheets)} sheets: {', '.join(sheets)}")
                        
                        if 'CombinedRegex_Summary' in sheets:
                            summary_df = pd.read_excel(xls, 'CombinedRegex_Summary')
                            print(f"✓ Summary sheet has {len(summary_df)} rows")
                        
                        if 'CombinedRegex_Breakdown' in sheets:
                            breakdown_df = pd.read_excel(xls, 'CombinedRegex_Breakdown')
                            print(f"✓ Breakdown sheet has {len(breakdown_df)} rows")
                    
                    # Clean up output file
                    os.unlink(save_result['filename'])
                    print("✓ Test output file cleaned up")
                    
                else:
                    print(f"✗ Output file not found: {save_result['filename']}")
                    return False
            else:
                print(f"✗ Save failed: {save_result['message']}")
                return False
            
            print("\n" + "=" * 60)
            print("✅ ALL TESTS PASSED! Combination functionality is working correctly.")
            return True
            
        else:
            print(f"✗ Pattern combination failed: {combination_result['message']}")
            return False
            
    except Exception as e:
        print(f"✗ Test failed with error: {str(e)}")
        return False
    
    finally:
        # Clean up temporary test file
        if os.path.exists(test_file):
            os.unlink(test_file)

if __name__ == "__main__":
    success = test_combination_functionality()
    
    if success:
        print("\n🎉 Regex combination enhancement is ready for use!")
    else:
        print("\n❌ Tests failed. Please check the error messages above.")